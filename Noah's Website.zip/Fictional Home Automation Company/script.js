var theme = document.getElementsByTagName('link')[0]; 

function switchTheme(newTheme) {
	// Changes the theme
	if (theme.getAttribute('href') == newTheme) {
		theme.setAttribute('href','light.css');
	} else {
		theme.setAttribute('href',newTheme);
	}
}
function Toggle(section) {
	// Opens and closes sections
	if (document.getElementById(section).style.display == 'none') {
		document.getElementById(section).style.display = 'block';
	}
	else {
		document.getElementById(section).style.display = 'none';
	}
}
function alter(spans,selection) {
	// Changes what a section says to align with user input
	for (let span of spans) {
		document.getElementById(span).innerHTML = document.getElementById(selection).value;
	}
}